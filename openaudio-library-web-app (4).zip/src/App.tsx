import { type FormEvent, type ReactNode, useEffect, useMemo, useRef, useState } from "react";
import { cn } from "./utils/cn";
import {
  CATEGORY_OPTIONS,
  type Audiobook,
  type AudiobookPreview,
  type CategoryId,
  formatClock,
  getAudiobookDetails,
  getCategoryCollection,
  getFeaturedAudiobooks,
  searchAudiobooks,
} from "./lib/audiobooks";
import {
  getGutenbergCollection,
  type GutenbergBook,
  searchGutenbergBooks,
} from "./lib/gutenberg";

const FAVORITES_KEY = "openaudio:favorites";
const RECENT_KEY = "openaudio:recent";
const PROGRESS_KEY = "openaudio:progress";

interface SavedProgress {
  book: AudiobookPreview;
  chapterId: string;
  chapterIndex: number;
  chapterTitle: string;
  audioUrl: string;
  currentTime: number;
  duration: number;
  updatedAt: number;
}

interface RecentEntry {
  book: AudiobookPreview;
  chapterTitle: string;
  currentTime: number;
  updatedAt: number;
}

interface PlayerState {
  book: Audiobook;
  chapterIndex: number;
}

function readStored<T>(key: string, fallback: T): T {
  if (typeof window === "undefined") return fallback;

  try {
    const raw = window.localStorage.getItem(key);
    return raw ? (JSON.parse(raw) as T) : fallback;
  } catch {
    return fallback;
  }
}

function writeStored<T>(key: string, value: T) {
  if (typeof window === "undefined") return;

  try {
    window.localStorage.setItem(key, JSON.stringify(value));
  } catch {
    // Ignore storage errors.
  }
}

function toPreview(book: Audiobook | AudiobookPreview): AudiobookPreview {
  return {
    id: book.id,
    source: book.source,
    sourceId: book.sourceId,
    archiveId: book.archiveId,
    title: book.title,
    author: book.author,
    description: book.description,
    coverUrl: book.coverUrl,
    durationSeconds: book.durationSeconds,
    durationLabel: book.durationLabel,
    chapterCount: book.chapterCount,
    categories: book.categories,
    sourceUrl: book.sourceUrl,
    downloadUrl: book.downloadUrl,
  };
}

function clamp(value: number, min: number, max: number) {
  return Math.min(max, Math.max(min, value));
}

function relativeTimeLabel(timestamp: number) {
  const diff = Date.now() - timestamp;
  const minutes = Math.floor(diff / 60000);

  if (minutes < 1) return "Just now";
  if (minutes < 60) return `${minutes}m ago`;

  const hours = Math.floor(minutes / 60);
  if (hours < 24) return `${hours}h ago`;

  const days = Math.floor(hours / 24);
  return `${days}d ago`;
}

function compactNumber(value: number) {
  return new Intl.NumberFormat(undefined, { notation: "compact", maximumFractionDigits: 1 }).format(value || 0);
}

function pushFavorite(list: AudiobookPreview[], book: AudiobookPreview) {
  const next = [book, ...list.filter((entry) => entry.id !== book.id)];
  return next.slice(0, 24);
}

function removeFavorite(list: AudiobookPreview[], bookId: string) {
  return list.filter((entry) => entry.id !== bookId);
}

function pushRecent(list: RecentEntry[], book: AudiobookPreview, chapterTitle: string, currentTime: number) {
  const next = [
    {
      book,
      chapterTitle,
      currentTime,
      updatedAt: Date.now(),
    },
    ...list.filter((entry) => entry.book.id !== book.id),
  ];

  return next.slice(0, 8);
}

function dedupeGutenbergBooks(books: GutenbergBook[]) {
  const seen = new Set<string>();
  return books.filter((book) => {
    if (seen.has(book.id)) return false;
    seen.add(book.id);
    return true;
  });
}

function EmptyArtwork({ title }: { title: string }) {
  return (
    <div className="flex h-full w-full items-center justify-center bg-gradient-to-br from-zinc-800 via-zinc-900 to-black text-zinc-400">
      <div className="flex flex-col items-center gap-2 px-4 text-center">
        <div className="rounded-full border border-white/10 bg-white/5 px-3 py-1 text-[10px] uppercase tracking-[0.3em] text-zinc-300">
          OpenAudio
        </div>
        <div className="text-sm font-medium text-zinc-200">{title}</div>
      </div>
    </div>
  );
}

function Cover({ title, coverUrl, className }: { title: string; coverUrl?: string; className?: string }) {
  const [broken, setBroken] = useState(false);

  if (!coverUrl || broken) {
    return (
      <div className={cn("overflow-hidden rounded-2xl border border-white/10", className)}>
        <EmptyArtwork title={title} />
      </div>
    );
  }

  return (
    <div className={cn("overflow-hidden rounded-2xl border border-white/10 bg-zinc-900", className)}>
      <img
        src={coverUrl}
        alt={`${title} cover`}
        className="h-full w-full object-cover"
        loading="lazy"
        referrerPolicy="no-referrer"
        onError={() => setBroken(true)}
      />
    </div>
  );
}

function SectionHeading({
  eyebrow,
  title,
  description,
  action,
}: {
  eyebrow: string;
  title: string;
  description: string;
  action?: ReactNode;
}) {
  return (
    <div className="flex flex-col gap-3 sm:flex-row sm:items-end sm:justify-between">
      <div className="space-y-1">
        <p className="text-[11px] uppercase tracking-[0.28em] text-zinc-500">{eyebrow}</p>
        <h2 className="text-2xl font-semibold tracking-tight text-white">{title}</h2>
        <p className="max-w-3xl text-sm text-zinc-400">{description}</p>
      </div>
      {action}
    </div>
  );
}

function BookCard({
  book,
  onOpen,
  onPlay,
  onToggleFavorite,
  isFavorite,
  progress,
}: {
  book: AudiobookPreview;
  onOpen: (book: AudiobookPreview) => void;
  onPlay: (book: AudiobookPreview, mode: "start" | "resume") => void;
  onToggleFavorite: (book: AudiobookPreview) => void;
  isFavorite: boolean;
  progress?: SavedProgress;
}) {
  const progressRatio = progress?.duration
    ? clamp((progress.currentTime / progress.duration) * 100, 0, 100)
    : progress?.book.durationSeconds
      ? clamp((progress.currentTime / progress.book.durationSeconds) * 100, 0, 100)
      : 0;

  return (
    <article className="group flex h-full flex-col rounded-3xl border border-white/10 bg-white/5 p-4 shadow-[0_20px_60px_rgba(0,0,0,0.25)] backdrop-blur-sm transition hover:border-white/15 hover:bg-white/[0.07]">
      <div className="mb-4 flex items-start justify-between gap-3">
        <span className="rounded-full border border-white/10 bg-black/30 px-2.5 py-1 text-[10px] uppercase tracking-[0.25em] text-zinc-400">
          {book.source === "librivox" ? "LibriVox" : "Archive fallback"}
        </span>
        <button
          type="button"
          onClick={() => onToggleFavorite(book)}
          className={cn(
            "rounded-full border px-2.5 py-1 text-xs transition",
            isFavorite
              ? "border-amber-400/30 bg-amber-400/10 text-amber-200"
              : "border-white/10 bg-black/20 text-zinc-400 hover:border-white/20 hover:text-zinc-200",
          )}
          aria-label={isFavorite ? `Remove ${book.title} from favorites` : `Save ${book.title} to favorites`}
        >
          {isFavorite ? "Saved" : "Save"}
        </button>
      </div>

      <button type="button" onClick={() => onOpen(book)} className="text-left">
        <Cover title={book.title} coverUrl={book.coverUrl} className="aspect-[4/5] w-full transition group-hover:scale-[1.01]" />
      </button>

      <div className="mt-4 flex flex-1 flex-col">
        <div className="space-y-2">
          <button type="button" onClick={() => onOpen(book)} className="text-left">
            <h3 className="text-lg font-medium tracking-tight text-white transition group-hover:text-zinc-100">
              {book.title}
            </h3>
          </button>
          <p className="text-sm text-zinc-400">{book.author}</p>
          <p
            className="min-h-[3.75rem] text-sm leading-6 text-zinc-500"
            style={{ display: "-webkit-box", WebkitLineClamp: 3, WebkitBoxOrient: "vertical", overflow: "hidden" }}
          >
            {book.description}
          </p>
        </div>

        <div className="mt-4 flex flex-wrap gap-2 text-xs text-zinc-400">
          <span className="rounded-full border border-white/10 px-2.5 py-1">{book.durationLabel}</span>
          <span className="rounded-full border border-white/10 px-2.5 py-1">
            {book.chapterCount || 1} {book.chapterCount === 1 ? "chapter" : "chapters"}
          </span>
          <span className="rounded-full border border-white/10 px-2.5 py-1">Public domain</span>
        </div>

        {progress ? (
          <div className="mt-4 rounded-2xl border border-white/10 bg-black/20 p-3">
            <div className="mb-2 flex items-center justify-between text-xs text-zinc-400">
              <span className="truncate pr-3">Continue · {progress.chapterTitle}</span>
              <span>{formatClock(progress.currentTime)}</span>
            </div>
            <div className="h-1.5 overflow-hidden rounded-full bg-white/10">
              <div className="h-full rounded-full bg-zinc-100" style={{ width: `${progressRatio}%` }} />
            </div>
          </div>
        ) : null}

        <div className="mt-5 flex gap-2">
          <button
            type="button"
            onClick={() => onPlay(book, progress ? "resume" : "start")}
            className="flex-1 rounded-2xl bg-white px-4 py-2.5 text-sm font-medium text-zinc-950 transition hover:bg-zinc-200"
          >
            {progress ? "Resume" : "Play"}
          </button>
          <button
            type="button"
            onClick={() => onOpen(book)}
            className="rounded-2xl border border-white/10 px-4 py-2.5 text-sm text-zinc-200 transition hover:border-white/20 hover:bg-white/5"
          >
            Details
          </button>
        </div>
      </div>
    </article>
  );
}

function GutenbergCard({ book }: { book: GutenbergBook }) {
  const primaryLink = book.readUrl || book.textUrl || book.epubUrl || book.sourceUrl;
  const tags = [book.mediaType, ...book.languages.slice(0, 2).map((language) => language.toUpperCase())].filter(Boolean);

  return (
    <article className="group flex h-full flex-col rounded-3xl border border-white/10 bg-white/5 p-4 shadow-[0_20px_60px_rgba(0,0,0,0.2)] transition hover:border-white/15 hover:bg-white/[0.07]">
      <div className="mb-4 flex items-start justify-between gap-3">
        <span className="rounded-full border border-emerald-400/20 bg-emerald-400/10 px-2.5 py-1 text-[10px] uppercase tracking-[0.25em] text-emerald-200">
          Gutenberg
        </span>
        <span className="rounded-full border border-white/10 px-2.5 py-1 text-[10px] uppercase tracking-[0.25em] text-zinc-500">
          {compactNumber(book.downloadCount)} downloads
        </span>
      </div>

      <a href={primaryLink} target="_blank" rel="noreferrer" className="text-left">
        <Cover title={book.title} coverUrl={book.coverUrl} className="aspect-[4/5] w-full transition group-hover:scale-[1.01]" />
      </a>

      <div className="mt-4 flex flex-1 flex-col">
        <div className="space-y-2">
          <a href={primaryLink} target="_blank" rel="noreferrer" className="block text-left">
            <h3 className="text-lg font-medium tracking-tight text-white transition group-hover:text-zinc-100">{book.title}</h3>
          </a>
          <p className="text-sm text-zinc-400">{book.author}</p>
          <p
            className="min-h-[4.5rem] text-sm leading-6 text-zinc-500"
            style={{ display: "-webkit-box", WebkitLineClamp: 3, WebkitBoxOrient: "vertical", overflow: "hidden" }}
          >
            {book.summary}
          </p>
        </div>

        <div className="mt-4 flex flex-wrap gap-2 text-xs text-zinc-400">
          {tags.map((tag) => (
            <span key={tag} className="rounded-full border border-white/10 px-2.5 py-1">
              {tag}
            </span>
          ))}
          <span className="rounded-full border border-white/10 px-2.5 py-1">Public domain</span>
        </div>

        {book.bookshelves.length ? (
          <div className="mt-4 flex flex-wrap gap-2 text-xs text-zinc-500">
            {book.bookshelves.slice(0, 2).map((shelf) => (
              <span key={shelf} className="rounded-full border border-white/10 bg-black/20 px-2.5 py-1">
                {shelf.replace(/^Category:\s*/i, "")}
              </span>
            ))}
          </div>
        ) : null}

        <div className="mt-5 flex flex-wrap gap-2">
          {book.readUrl ? (
            <a
              href={book.readUrl}
              target="_blank"
              rel="noreferrer"
              className="rounded-2xl bg-white px-4 py-2.5 text-sm font-medium text-zinc-950 transition hover:bg-zinc-200"
            >
              Read
            </a>
          ) : null}
          {book.epubUrl ? (
            <a
              href={book.epubUrl}
              target="_blank"
              rel="noreferrer"
              className="rounded-2xl border border-white/10 px-4 py-2.5 text-sm text-zinc-200 transition hover:border-white/20 hover:bg-white/5"
            >
              EPUB
            </a>
          ) : null}
          {book.audioUrl ? (
            <a
              href={book.audioUrl}
              target="_blank"
              rel="noreferrer"
              className="rounded-2xl border border-sky-400/20 bg-sky-400/10 px-4 py-2.5 text-sm text-sky-100 transition hover:border-sky-400/30 hover:bg-sky-400/15"
            >
              Listen
            </a>
          ) : null}
          <a
            href={book.sourceUrl}
            target="_blank"
            rel="noreferrer"
            className="rounded-2xl border border-white/10 px-4 py-2.5 text-sm text-zinc-200 transition hover:border-white/20 hover:bg-white/5"
          >
            Source
          </a>
        </div>
      </div>
    </article>
  );
}

function LoadingCard() {
  return (
    <div className="rounded-3xl border border-white/10 bg-white/5 p-4">
      <div className="aspect-[4/5] animate-pulse rounded-2xl bg-white/8" />
      <div className="mt-4 space-y-2">
        <div className="h-5 w-3/4 animate-pulse rounded bg-white/8" />
        <div className="h-4 w-1/2 animate-pulse rounded bg-white/8" />
        <div className="h-4 w-full animate-pulse rounded bg-white/8" />
        <div className="h-4 w-5/6 animate-pulse rounded bg-white/8" />
      </div>
    </div>
  );
}

export default function App() {
  const audioRef = useRef<HTMLAudioElement | null>(null);
  const sleepTimerRef = useRef<number | null>(null);
  const pendingSeekRef = useRef<number>(0);
  const lastSavedSecondRef = useRef<Record<string, number>>({});
  const libraryRequestRef = useRef(0);
  const gutenbergRequestRef = useRef(0);

  const [query, setQuery] = useState("");
  const [activeCategory, setActiveCategory] = useState<CategoryId>("Classics");
  const [featured, setFeatured] = useState<AudiobookPreview[]>([]);
  const [library, setLibrary] = useState<AudiobookPreview[]>([]);
  const [selectedBook, setSelectedBook] = useState<Audiobook | null>(null);
  const [favorites, setFavorites] = useState<AudiobookPreview[]>(() => readStored(FAVORITES_KEY, []));
  const [recentlyPlayed, setRecentlyPlayed] = useState<RecentEntry[]>(() => readStored(RECENT_KEY, []));
  const [progressMap, setProgressMap] = useState<Record<string, SavedProgress>>(() => readStored(PROGRESS_KEY, {}));
  const [player, setPlayer] = useState<PlayerState | null>(null);
  const [isPlaying, setIsPlaying] = useState(false);
  const [currentTime, setCurrentTime] = useState(0);
  const [duration, setDuration] = useState(0);
  const [playbackRate, setPlaybackRate] = useState(1);
  const [sleepMinutes, setSleepMinutes] = useState(0);
  const [loadingFeatured, setLoadingFeatured] = useState(true);
  const [loadingLibrary, setLoadingLibrary] = useState(true);
  const [loadingGutenberg, setLoadingGutenberg] = useState(true);
  const [loadingMoreGutenberg, setLoadingMoreGutenberg] = useState(false);
  const [libraryLabel, setLibraryLabel] = useState("Classics");
  const [gutenbergLabel, setGutenbergLabel] = useState("Project Gutenberg · Classics");
  const [gutenbergBooks, setGutenbergBooks] = useState<GutenbergBook[]>([]);
  const [gutenbergNextUrl, setGutenbergNextUrl] = useState<string | null>(null);
  const [gutenbergTotal, setGutenbergTotal] = useState(0);
  const [error, setError] = useState("");
  const [gutenbergError, setGutenbergError] = useState("");

  const favoriteIds = useMemo(() => new Set(favorites.map((book) => book.id)), [favorites]);
  const currentChapter = player ? player.book.chapters[player.chapterIndex] : null;
  const currentProgress = currentChapter && duration > 0 ? (currentTime / duration) * 100 : 0;

  const recommendations = useMemo(() => {
    if (!selectedBook) return [];

    const pool = [...library, ...featured, ...favorites].filter((book) => book.id !== selectedBook.id);
    const unique = new Map<string, AudiobookPreview>();

    pool
      .sort((a, b) => {
        const authorScoreA = a.author === selectedBook.author ? 2 : 0;
        const authorScoreB = b.author === selectedBook.author ? 2 : 0;
        const categoryScoreA = a.categories.some((category) => selectedBook.categories.includes(category)) ? 1 : 0;
        const categoryScoreB = b.categories.some((category) => selectedBook.categories.includes(category)) ? 1 : 0;
        return authorScoreB + categoryScoreB - (authorScoreA + categoryScoreA);
      })
      .forEach((book) => {
        if (!unique.has(book.id)) unique.set(book.id, book);
      });

    return Array.from(unique.values()).slice(0, 4);
  }, [favorites, featured, library, selectedBook]);

  useEffect(() => {
    writeStored(FAVORITES_KEY, favorites);
  }, [favorites]);

  useEffect(() => {
    writeStored(RECENT_KEY, recentlyPlayed);
  }, [recentlyPlayed]);

  useEffect(() => {
    writeStored(PROGRESS_KEY, progressMap);
  }, [progressMap]);

  useEffect(() => {
    const audio = audioRef.current;
    if (!audio) return;
    audio.playbackRate = playbackRate;
  }, [playbackRate]);

  useEffect(() => {
    void loadFeatured();
    void loadLibraryCollection("Classics");
    void loadGutenbergShelf("Classics");
  }, []);

  useEffect(() => {
    return () => {
      if (sleepTimerRef.current) {
        window.clearTimeout(sleepTimerRef.current);
      }
    };
  }, []);

  useEffect(() => {
    const audio = audioRef.current;
    if (!audio) return;

    const attemptPlay = async () => {
      try {
        await audio.play();
        setIsPlaying(true);
      } catch {
        setIsPlaying(false);
      }
    };

    const handleLoadedMetadata = () => {
      const actualDuration = Number.isFinite(audio.duration) ? audio.duration : 0;
      const chapterDuration = currentChapter?.durationSeconds ?? 0;
      setDuration(actualDuration || chapterDuration || 0);

      if (pendingSeekRef.current > 0) {
        audio.currentTime = pendingSeekRef.current;
        setCurrentTime(pendingSeekRef.current);
      }

      pendingSeekRef.current = 0;
      audio.playbackRate = playbackRate;
      void attemptPlay();
    };

    const handleTimeUpdate = () => {
      setCurrentTime(audio.currentTime);

      if (!player || !currentChapter) return;

      const rounded = Math.floor(audio.currentTime);
      if (rounded > 0 && rounded % 5 === 0 && lastSavedSecondRef.current[player.book.id] !== rounded) {
        lastSavedSecondRef.current[player.book.id] = rounded;
        persistProgress(player.book, player.chapterIndex, audio.currentTime, audio.duration || duration || currentChapter.durationSeconds);
      }
    };

    const handlePlay = () => {
      setIsPlaying(true);
      if (player && currentChapter) {
        setRecentlyPlayed((prev) => pushRecent(prev, toPreview(player.book), currentChapter.title, audio.currentTime));
      }
    };

    const handlePause = () => {
      setIsPlaying(false);
      if (player && currentChapter) {
        persistProgress(player.book, player.chapterIndex, audio.currentTime, audio.duration || duration || currentChapter.durationSeconds);
      }
    };

    const handleEnded = () => {
      if (!player) {
        setIsPlaying(false);
        return;
      }

      const nextIndex = player.chapterIndex + 1;
      if (nextIndex < player.book.chapters.length) {
        playResolvedChapter(player.book, nextIndex, 0);
        return;
      }

      setIsPlaying(false);
    };

    const handleAudioError = () => {
      setIsPlaying(false);
      setError("This audio file could not be played in your browser right now.");
    };

    audio.addEventListener("loadedmetadata", handleLoadedMetadata);
    audio.addEventListener("timeupdate", handleTimeUpdate);
    audio.addEventListener("play", handlePlay);
    audio.addEventListener("pause", handlePause);
    audio.addEventListener("ended", handleEnded);
    audio.addEventListener("error", handleAudioError);

    return () => {
      audio.removeEventListener("loadedmetadata", handleLoadedMetadata);
      audio.removeEventListener("timeupdate", handleTimeUpdate);
      audio.removeEventListener("play", handlePlay);
      audio.removeEventListener("pause", handlePause);
      audio.removeEventListener("ended", handleEnded);
      audio.removeEventListener("error", handleAudioError);
    };
  }, [currentChapter, duration, playbackRate, player]);

  async function loadFeatured() {
    setLoadingFeatured(true);
    try {
      const books = await getFeaturedAudiobooks();
      setFeatured(books);
    } catch {
      setError("Unable to load featured public domain audiobooks right now.");
    } finally {
      setLoadingFeatured(false);
    }
  }

  async function loadLibraryCollection(category: CategoryId) {
    const requestId = ++libraryRequestRef.current;
    setLoadingLibrary(true);
    setError("");
    setLibraryLabel(category);

    try {
      const books = await getCategoryCollection(category);
      if (requestId !== libraryRequestRef.current) return;
      setLibrary(books);
    } catch {
      if (requestId !== libraryRequestRef.current) return;
      setLibrary([]);
      setError("Unable to load audiobooks right now. Please try another search.");
    } finally {
      if (requestId === libraryRequestRef.current) {
        setLoadingLibrary(false);
      }
    }
  }

  async function loadGutenbergShelf(category: CategoryId) {
    const requestId = ++gutenbergRequestRef.current;
    setLoadingGutenberg(true);
    setGutenbergError("");
    setGutenbergLabel(`Project Gutenberg · ${category}`);

    try {
      const result = await getGutenbergCollection(category);
      if (requestId !== gutenbergRequestRef.current) return;
      setGutenbergBooks(result.books);
      setGutenbergNextUrl(result.nextUrl);
      setGutenbergTotal(result.total);
    } catch {
      if (requestId !== gutenbergRequestRef.current) return;
      setGutenbergBooks([]);
      setGutenbergNextUrl(null);
      setGutenbergTotal(0);
      setGutenbergError("Project Gutenberg titles are unavailable right now.");
    } finally {
      if (requestId === gutenbergRequestRef.current) {
        setLoadingGutenberg(false);
      }
    }
  }

  async function handleSearchSubmit(event?: FormEvent<HTMLFormElement>) {
    event?.preventDefault();
    const term = query.trim();

    if (!term) {
      void loadLibraryCollection(activeCategory);
      void loadGutenbergShelf(activeCategory);
      return;
    }

    const audioRequestId = ++libraryRequestRef.current;
    const gutenbergRequestId = ++gutenbergRequestRef.current;

    setLoadingLibrary(true);
    setLoadingGutenberg(true);
    setError("");
    setGutenbergError("");
    setLibraryLabel(`Results for “${term}”`);
    setGutenbergLabel(`Project Gutenberg results for “${term}”`);

    const [audioResult, gutenbergResult] = await Promise.allSettled([searchAudiobooks(term), searchGutenbergBooks(term)]);

    if (audioRequestId === libraryRequestRef.current) {
      if (audioResult.status === "fulfilled") {
        setLibrary(audioResult.value);
      } else {
        setLibrary([]);
        setError("Search is temporarily unavailable. Please try a different title or author.");
      }
      setLoadingLibrary(false);
    }

    if (gutenbergRequestId === gutenbergRequestRef.current) {
      if (gutenbergResult.status === "fulfilled") {
        setGutenbergBooks(gutenbergResult.value.books);
        setGutenbergNextUrl(gutenbergResult.value.nextUrl);
        setGutenbergTotal(gutenbergResult.value.total);
      } else {
        setGutenbergBooks([]);
        setGutenbergNextUrl(null);
        setGutenbergTotal(0);
        setGutenbergError("Project Gutenberg search is temporarily unavailable.");
      }
      setLoadingGutenberg(false);
    }
  }

  async function handleLoadMoreGutenberg() {
    if (!gutenbergNextUrl) return;

    setLoadingMoreGutenberg(true);
    setGutenbergError("");

    try {
      const result = query.trim()
        ? await searchGutenbergBooks(query.trim(), gutenbergNextUrl)
        : await getGutenbergCollection(activeCategory, gutenbergNextUrl);

      setGutenbergBooks((prev) => dedupeGutenbergBooks([...prev, ...result.books]));
      setGutenbergNextUrl(result.nextUrl);
      setGutenbergTotal(result.total);
    } catch {
      setGutenbergError("More Project Gutenberg books could not be loaded right now.");
    } finally {
      setLoadingMoreGutenberg(false);
    }
  }

  function handleCategorySelect(category: CategoryId) {
    setActiveCategory(category);
    setQuery("");
    void loadLibraryCollection(category);
    void loadGutenbergShelf(category);
  }

  async function openBook(book: AudiobookPreview) {
    setError("");

    try {
      const details = await getAudiobookDetails(book);
      setSelectedBook(details);
      window.scrollTo({ top: 0, behavior: "smooth" });
    } catch {
      setError("This audiobook page could not be loaded right now.");
    }
  }

  function closeBook() {
    setSelectedBook(null);
    window.scrollTo({ top: 0, behavior: "smooth" });
  }

  function toggleFavorite(book: AudiobookPreview) {
    setFavorites((prev) =>
      prev.some((entry) => entry.id === book.id) ? removeFavorite(prev, book.id) : pushFavorite(prev, toPreview(book)),
    );
  }

  function persistProgress(book: Audiobook, chapterIndex: number, time: number, totalDuration: number) {
    const chapter = book.chapters[chapterIndex];
    if (!chapter) return;

    const preview = toPreview(book);
    const safeTime = clamp(time, 0, totalDuration || Number.MAX_SAFE_INTEGER);

    setProgressMap((prev) => ({
      ...prev,
      [book.id]: {
        book: preview,
        chapterId: chapter.id,
        chapterIndex,
        chapterTitle: chapter.title,
        audioUrl: chapter.audioUrl,
        currentTime: safeTime,
        duration: totalDuration || chapter.durationSeconds || book.durationSeconds || 0,
        updatedAt: Date.now(),
      },
    }));

    setRecentlyPlayed((prev) => pushRecent(prev, preview, chapter.title, safeTime));
  }

  function playResolvedChapter(book: Audiobook, chapterIndex: number, resumeFrom: number) {
    const audio = audioRef.current;
    const chapter = book.chapters[chapterIndex];
    if (!audio || !chapter) return;

    pendingSeekRef.current = resumeFrom;
    setPlayer({ book, chapterIndex });
    setDuration(chapter.durationSeconds || book.durationSeconds || 0);
    setCurrentTime(resumeFrom);
    setError("");
    audio.src = chapter.audioUrl;
    audio.preload = "metadata";
    audio.load();

    const preview = toPreview(book);
    setRecentlyPlayed((prev) => pushRecent(prev, preview, chapter.title, resumeFrom));
  }

  async function handlePlayBook(book: AudiobookPreview | Audiobook, mode: "start" | "resume") {
    try {
      const detailedBook = "chapters" in book ? book : await getAudiobookDetails(book);
      if (!detailedBook.chapters.length) {
        setError("No playable chapters were found for this audiobook.");
        return;
      }

      const saved = progressMap[detailedBook.id];
      const chapterIndex =
        mode === "resume" && saved
          ? clamp(saved.chapterIndex, 0, Math.max(0, detailedBook.chapters.length - 1))
          : 0;
      const resumeFrom = mode === "resume" && saved && saved.chapterIndex === chapterIndex ? saved.currentTime : 0;

      playResolvedChapter(detailedBook, chapterIndex, resumeFrom);
    } catch {
      setError("Playback is unavailable for this audiobook right now.");
    }
  }

  function handlePlayChapter(book: Audiobook, chapterIndex: number) {
    const saved = progressMap[book.id];
    const resumeFrom = saved && saved.chapterIndex === chapterIndex ? saved.currentTime : 0;
    playResolvedChapter(book, chapterIndex, resumeFrom);
  }

  function togglePlayback() {
    const audio = audioRef.current;
    if (!audio) return;

    if (audio.paused) {
      void audio.play().then(() => setIsPlaying(true)).catch(() => setIsPlaying(false));
      return;
    }

    audio.pause();
  }

  function handleSeek(value: number) {
    const audio = audioRef.current;
    if (!audio) return;
    audio.currentTime = value;
    setCurrentTime(value);
  }

  function handleSleepTimer(minutes: number) {
    setSleepMinutes(minutes);

    if (sleepTimerRef.current) {
      window.clearTimeout(sleepTimerRef.current);
      sleepTimerRef.current = null;
    }

    if (minutes <= 0) return;

    sleepTimerRef.current = window.setTimeout(() => {
      audioRef.current?.pause();
      setSleepMinutes(0);
    }, minutes * 60 * 1000);
  }

  const selectedProgress = selectedBook ? progressMap[selectedBook.id] : undefined;

  return (
    <div className="min-h-screen bg-zinc-950 text-zinc-100">
      <audio ref={audioRef} preload="none" playsInline crossOrigin="anonymous" />

      <div className="mx-auto flex min-h-screen w-full max-w-7xl flex-col px-4 pb-40 pt-5 sm:px-6 lg:px-8">
        <header className="sticky top-0 z-30 mb-8 border-b border-white/10 bg-zinc-950/85 py-4 backdrop-blur-xl">
          <div className="flex flex-col gap-5 lg:flex-row lg:items-center lg:justify-between">
            <div className="space-y-2">
              <div className="inline-flex items-center gap-2 rounded-full border border-white/10 bg-white/5 px-3 py-1 text-[11px] uppercase tracking-[0.28em] text-zinc-400">
                <span className="h-2 w-2 rounded-full bg-emerald-400" />
                Public domain only
              </div>
              <div>
                <h1 className="text-3xl font-semibold tracking-tight text-white sm:text-4xl">OpenAudio Library</h1>
                <p className="mt-2 max-w-3xl text-sm leading-6 text-zinc-400 sm:text-base">
                  A minimal listening and reading space for free public domain audiobooks from LibriVox plus the full
                  Project Gutenberg catalog for text editions and additional public domain media.
                </p>
              </div>
            </div>

            <form onSubmit={handleSearchSubmit} className="flex w-full max-w-2xl flex-col gap-3 sm:flex-row">
              <div className="relative flex-1">
                <input
                  value={query}
                  onChange={(event) => setQuery(event.target.value)}
                  placeholder="Search audiobooks, titles, authors, or Gutenberg books"
                  className="h-12 w-full rounded-2xl border border-white/10 bg-white/5 px-4 text-sm text-white outline-none transition placeholder:text-zinc-500 focus:border-white/20 focus:bg-white/[0.07]"
                />
              </div>
              <button
                type="submit"
                className="h-12 rounded-2xl bg-white px-5 text-sm font-medium text-zinc-950 transition hover:bg-zinc-200"
              >
                Search
              </button>
            </form>
          </div>
        </header>

        {error ? (
          <div className="mb-4 rounded-2xl border border-rose-400/20 bg-rose-400/10 px-4 py-3 text-sm text-rose-100">
            {error}
          </div>
        ) : null}

        {gutenbergError ? (
          <div className="mb-6 rounded-2xl border border-amber-400/20 bg-amber-400/10 px-4 py-3 text-sm text-amber-100">
            {gutenbergError}
          </div>
        ) : null}

        {selectedBook ? (
          <main className="space-y-10">
            <button
              type="button"
              onClick={closeBook}
              className="inline-flex items-center gap-2 rounded-full border border-white/10 bg-white/5 px-4 py-2 text-sm text-zinc-200 transition hover:border-white/20 hover:bg-white/[0.08]"
            >
              ← Back to library
            </button>

            <section className="grid gap-8 lg:grid-cols-[320px_minmax(0,1fr)]">
              <div className="space-y-5">
                <Cover title={selectedBook.title} coverUrl={selectedBook.coverUrl} className="aspect-[4/5] w-full" />

                <div className="grid grid-cols-2 gap-3 sm:grid-cols-4 lg:grid-cols-2">
                  {[
                    { label: "Author", value: selectedBook.author },
                    { label: "Length", value: selectedBook.durationLabel },
                    { label: "Chapters", value: `${selectedBook.chapterCount || selectedBook.chapters.length || 1}` },
                    { label: "Source", value: selectedBook.source === "librivox" ? "LibriVox" : "Archive" },
                  ].map((item) => (
                    <div key={item.label} className="rounded-2xl border border-white/10 bg-white/5 p-4">
                      <p className="text-[11px] uppercase tracking-[0.25em] text-zinc-500">{item.label}</p>
                      <p className="mt-2 text-sm font-medium text-zinc-100">{item.value}</p>
                    </div>
                  ))}
                </div>
              </div>

              <div className="space-y-8">
                <div className="space-y-4">
                  <div className="flex flex-wrap items-center gap-2 text-xs text-zinc-400">
                    <span className="rounded-full border border-white/10 px-2.5 py-1">Public domain</span>
                    {selectedBook.categories.slice(0, 3).map((category) => (
                      <span key={category} className="rounded-full border border-white/10 px-2.5 py-1">
                        {category}
                      </span>
                    ))}
                  </div>

                  <div>
                    <h2 className="text-3xl font-semibold tracking-tight text-white sm:text-4xl">{selectedBook.title}</h2>
                    <p className="mt-3 text-base text-zinc-400">by {selectedBook.author}</p>
                  </div>

                  <p className="max-w-3xl text-sm leading-7 text-zinc-300 sm:text-base">{selectedBook.description}</p>

                  <div className="flex flex-wrap gap-3">
                    <button
                      type="button"
                      onClick={() => void handlePlayBook(selectedBook, selectedProgress ? "resume" : "start")}
                      className="rounded-2xl bg-white px-5 py-3 text-sm font-medium text-zinc-950 transition hover:bg-zinc-200"
                    >
                      {selectedProgress ? `Continue ${formatClock(selectedProgress.currentTime)}` : "Play from the beginning"}
                    </button>
                    <button
                      type="button"
                      onClick={() => toggleFavorite(toPreview(selectedBook))}
                      className={cn(
                        "rounded-2xl border px-5 py-3 text-sm transition",
                        favoriteIds.has(selectedBook.id)
                          ? "border-amber-400/30 bg-amber-400/10 text-amber-100"
                          : "border-white/10 bg-white/5 text-zinc-200 hover:border-white/20 hover:bg-white/[0.08]",
                      )}
                    >
                      {favoriteIds.has(selectedBook.id) ? "Saved to favorites" : "Save to favorites"}
                    </button>
                    {selectedBook.downloadUrl ? (
                      <a
                        href={selectedBook.downloadUrl}
                        target="_blank"
                        rel="noreferrer"
                        className="rounded-2xl border border-white/10 bg-white/5 px-5 py-3 text-sm text-zinc-200 transition hover:border-white/20 hover:bg-white/[0.08]"
                      >
                        Download
                      </a>
                    ) : null}
                    {selectedBook.sourceUrl ? (
                      <a
                        href={selectedBook.sourceUrl}
                        target="_blank"
                        rel="noreferrer"
                        className="rounded-2xl border border-white/10 bg-white/5 px-5 py-3 text-sm text-zinc-200 transition hover:border-white/20 hover:bg-white/[0.08]"
                      >
                        Open source page
                      </a>
                    ) : null}
                  </div>
                </div>

                <section className="space-y-5">
                  <SectionHeading
                    eyebrow="Book page"
                    title="Chapter list"
                    description="Play any chapter directly. Progress is saved locally so you can continue later without an account."
                  />

                  <div className="space-y-3">
                    {selectedBook.chapters.map((chapter, index) => {
                      const isCurrent = player?.book.id === selectedBook.id && player.chapterIndex === index;
                      const resumeForChapter =
                        selectedProgress && selectedProgress.chapterIndex === index ? selectedProgress.currentTime : 0;

                      return (
                        <div
                          key={chapter.id}
                          className={cn(
                            "rounded-2xl border p-4 transition",
                            isCurrent ? "border-white/20 bg-white/[0.09]" : "border-white/10 bg-white/5",
                          )}
                        >
                          <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
                            <div className="min-w-0 flex-1">
                              <div className="flex flex-wrap items-center gap-2 text-xs text-zinc-500">
                                <span>Chapter {index + 1}</span>
                                {chapter.durationLabel !== "—" ? <span>• {chapter.durationLabel}</span> : null}
                                {chapter.reader ? <span>• {chapter.reader}</span> : null}
                                {resumeForChapter > 0 ? <span>• Resume at {formatClock(resumeForChapter)}</span> : null}
                              </div>
                              <h3 className="mt-2 truncate text-sm font-medium text-zinc-100 sm:text-base">{chapter.title}</h3>
                            </div>

                            <div className="flex shrink-0 gap-2">
                              <button
                                type="button"
                                onClick={() => handlePlayChapter(selectedBook, index)}
                                className="rounded-2xl bg-white px-4 py-2.5 text-sm font-medium text-zinc-950 transition hover:bg-zinc-200"
                              >
                                {isCurrent && isPlaying ? "Playing" : resumeForChapter > 0 ? "Resume" : "Play"}
                              </button>
                              <a
                                href={chapter.audioUrl}
                                target="_blank"
                                rel="noreferrer"
                                className="rounded-2xl border border-white/10 px-4 py-2.5 text-sm text-zinc-200 transition hover:border-white/20 hover:bg-white/5"
                              >
                                Download
                              </a>
                            </div>
                          </div>
                        </div>
                      );
                    })}
                  </div>
                </section>

                {recommendations.length ? (
                  <section className="space-y-5">
                    <SectionHeading
                      eyebrow="Simple recommendations"
                      title="Keep the listening flow going"
                      description="A few more public domain titles related by category, author, or the collections you’ve already explored."
                    />
                    <div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-4">
                      {recommendations.map((book) => (
                        <BookCard
                          key={book.id}
                          book={book}
                          onOpen={(entry) => void openBook(entry)}
                          onPlay={(entry, mode) => void handlePlayBook(entry, mode)}
                          onToggleFavorite={toggleFavorite}
                          isFavorite={favoriteIds.has(book.id)}
                          progress={progressMap[book.id]}
                        />
                      ))}
                    </div>
                  </section>
                ) : null}
              </div>
            </section>
          </main>
        ) : (
          <main className="space-y-12">
            <section className="rounded-[2rem] border border-white/10 bg-gradient-to-br from-white/8 via-white/[0.04] to-transparent p-6 sm:p-8">
              <div className="grid gap-8 lg:grid-cols-[minmax(0,1.05fr)_minmax(320px,0.95fr)] lg:items-end">
                <div className="space-y-6">
                  <div className="space-y-3">
                    <p className="text-[11px] uppercase tracking-[0.28em] text-zinc-500">Minimal listening + reading</p>
                    <h2 className="max-w-3xl text-3xl font-semibold tracking-tight text-white sm:text-5xl">
                      Public domain audiobooks, plus instant access to the wider Gutenberg book catalog.
                    </h2>
                    <p className="max-w-2xl text-sm leading-7 text-zinc-400 sm:text-base">
                      Listen with chapter progress saved locally, then jump to matching public domain text editions from
                      Project Gutenberg when you want the book beside the audio.
                    </p>
                  </div>

                  <div className="grid gap-3 sm:grid-cols-3">
                    <div className="rounded-3xl border border-white/10 bg-black/20 p-4">
                      <p className="text-[11px] uppercase tracking-[0.24em] text-zinc-500">Audiobooks</p>
                      <p className="mt-2 text-2xl font-semibold text-white">LibriVox-first</p>
                      <p className="mt-1 text-sm text-zinc-400">Built-in player with resume, seek, and speed control.</p>
                    </div>
                    <div className="rounded-3xl border border-white/10 bg-black/20 p-4">
                      <p className="text-[11px] uppercase tracking-[0.24em] text-zinc-500">Books</p>
                      <p className="mt-2 text-2xl font-semibold text-white">{compactNumber(gutenbergTotal || 78177)}+</p>
                      <p className="mt-1 text-sm text-zinc-400">Project Gutenberg public domain titles, searchable in-app.</p>
                    </div>
                    <div className="rounded-3xl border border-white/10 bg-black/20 p-4">
                      <p className="text-[11px] uppercase tracking-[0.24em] text-zinc-500">Saved locally</p>
                      <p className="mt-2 text-2xl font-semibold text-white">No login</p>
                      <p className="mt-1 text-sm text-zinc-400">Favorites, recent plays, and listening progress stay on device.</p>
                    </div>
                  </div>
                </div>

                <div className="grid gap-3 sm:grid-cols-2">
                  {CATEGORY_OPTIONS.map((category) => (
                    <button
                      key={category.id}
                      type="button"
                      onClick={() => handleCategorySelect(category.id)}
                      className={cn(
                        "rounded-3xl border p-4 text-left transition",
                        activeCategory === category.id && !query.trim()
                          ? "border-white/20 bg-white/[0.09]"
                          : "border-white/10 bg-white/5 hover:border-white/15 hover:bg-white/[0.07]",
                      )}
                    >
                      <div className="space-y-2">
                        <p className="text-sm font-medium text-white">{category.label}</p>
                        <p className="text-sm leading-6 text-zinc-400">{category.description}</p>
                      </div>
                    </button>
                  ))}
                </div>
              </div>
            </section>

            {recentlyPlayed.length ? (
              <section className="space-y-5">
                <SectionHeading
                  eyebrow="Recent"
                  title="Recently played"
                  description="Jump back into the audiobooks you were listening to on this device."
                />
                <div className="grid gap-4 md:grid-cols-2 xl:grid-cols-4">
                  {recentlyPlayed.map((entry) => (
                    <button
                      key={entry.book.id}
                      type="button"
                      onClick={() => void handlePlayBook(entry.book, "resume")}
                      className="flex items-center gap-4 rounded-3xl border border-white/10 bg-white/5 p-4 text-left transition hover:border-white/15 hover:bg-white/[0.07]"
                    >
                      <Cover title={entry.book.title} coverUrl={entry.book.coverUrl} className="h-24 w-20 shrink-0" />
                      <div className="min-w-0">
                        <p className="truncate text-sm font-medium text-white">{entry.book.title}</p>
                        <p className="mt-1 truncate text-sm text-zinc-400">{entry.book.author}</p>
                        <p className="mt-2 text-xs text-zinc-500">{entry.chapterTitle}</p>
                        <p className="mt-1 text-xs text-zinc-500">
                          {formatClock(entry.currentTime)} • {relativeTimeLabel(entry.updatedAt)}
                        </p>
                      </div>
                    </button>
                  ))}
                </div>
              </section>
            ) : null}

            {favorites.length ? (
              <section className="space-y-5">
                <SectionHeading
                  eyebrow="Saved"
                  title="Favorites"
                  description="Your locally saved audiobook library, ready whenever you come back."
                />
                <div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-4">
                  {favorites.slice(0, 4).map((book) => (
                    <BookCard
                      key={book.id}
                      book={book}
                      onOpen={(entry) => void openBook(entry)}
                      onPlay={(entry, mode) => void handlePlayBook(entry, mode)}
                      onToggleFavorite={toggleFavorite}
                      isFavorite={favoriteIds.has(book.id)}
                      progress={progressMap[book.id]}
                    />
                  ))}
                </div>
              </section>
            ) : null}

            <section className="space-y-5">
              <SectionHeading
                eyebrow="Featured"
                title="Featured audiobooks"
                description="A curated set of public domain listens to start with."
              />

              <div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-4">
                {loadingFeatured
                  ? Array.from({ length: 4 }).map((_, index) => <LoadingCard key={index} />)
                  : featured.map((book) => (
                      <BookCard
                        key={book.id}
                        book={book}
                        onOpen={(entry) => void openBook(entry)}
                        onPlay={(entry, mode) => void handlePlayBook(entry, mode)}
                        onToggleFavorite={toggleFavorite}
                        isFavorite={favoriteIds.has(book.id)}
                        progress={progressMap[book.id]}
                      />
                    ))}
              </div>
            </section>

            <section className="space-y-5">
              <SectionHeading
                eyebrow="Audiobooks"
                title={libraryLabel}
                description="Browse public domain audiobooks with LibriVox as the primary source and Internet Archive fallback when needed."
                action={
                  <div className="flex flex-wrap gap-2">
                    {CATEGORY_OPTIONS.map((category) => (
                      <button
                        key={category.id}
                        type="button"
                        onClick={() => handleCategorySelect(category.id)}
                        className={cn(
                          "rounded-full border px-4 py-2 text-sm transition",
                          activeCategory === category.id && !query.trim()
                            ? "border-white/20 bg-white/[0.09] text-white"
                            : "border-white/10 bg-white/5 text-zinc-300 hover:border-white/15 hover:bg-white/[0.08]",
                        )}
                      >
                        {category.label}
                      </button>
                    ))}
                  </div>
                }
              />

              {loadingLibrary ? (
                <div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-4">
                  {Array.from({ length: 8 }).map((_, index) => (
                    <LoadingCard key={index} />
                  ))}
                </div>
              ) : library.length ? (
                <div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-4">
                  {library.map((book) => (
                    <BookCard
                      key={book.id}
                      book={book}
                      onOpen={(entry) => void openBook(entry)}
                      onPlay={(entry, mode) => void handlePlayBook(entry, mode)}
                      onToggleFavorite={toggleFavorite}
                      isFavorite={favoriteIds.has(book.id)}
                      progress={progressMap[book.id]}
                    />
                  ))}
                </div>
              ) : (
                <div className="rounded-3xl border border-dashed border-white/10 bg-white/[0.03] p-10 text-center">
                  <p className="text-lg font-medium text-white">No matching public domain audiobooks found.</p>
                  <p className="mt-2 text-sm text-zinc-400">Try another title, author, or switch to a category.</p>
                </div>
              )}
            </section>

            <section className="space-y-5">
              <SectionHeading
                eyebrow="Project Gutenberg"
                title={gutenbergLabel}
                description={`Browse the wider Project Gutenberg catalog directly in the app. ${compactNumber(gutenbergTotal || 0)} public domain books currently match this view.`}
                action={
                  gutenbergNextUrl ? (
                    <button
                      type="button"
                      onClick={() => void handleLoadMoreGutenberg()}
                      disabled={loadingMoreGutenberg}
                      className="rounded-2xl border border-white/10 bg-white/5 px-4 py-2.5 text-sm text-zinc-200 transition hover:border-white/20 hover:bg-white/[0.08] disabled:cursor-not-allowed disabled:opacity-60"
                    >
                      {loadingMoreGutenberg ? "Loading more…" : "Load more books"}
                    </button>
                  ) : null
                }
              />

              {loadingGutenberg ? (
                <div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-4">
                  {Array.from({ length: 8 }).map((_, index) => (
                    <LoadingCard key={index} />
                  ))}
                </div>
              ) : gutenbergBooks.length ? (
                <>
                  <div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-4">
                    {gutenbergBooks.map((book) => (
                      <GutenbergCard key={book.id} book={book} />
                    ))}
                  </div>

                  {gutenbergNextUrl ? (
                    <div className="flex justify-center pt-2">
                      <button
                        type="button"
                        onClick={() => void handleLoadMoreGutenberg()}
                        disabled={loadingMoreGutenberg}
                        className="rounded-2xl bg-white px-5 py-3 text-sm font-medium text-zinc-950 transition hover:bg-zinc-200 disabled:cursor-not-allowed disabled:opacity-60"
                      >
                        {loadingMoreGutenberg ? "Loading more books…" : "Load more from Gutenberg"}
                      </button>
                    </div>
                  ) : null}
                </>
              ) : (
                <div className="rounded-3xl border border-dashed border-white/10 bg-white/[0.03] p-10 text-center">
                  <p className="text-lg font-medium text-white">No matching Project Gutenberg books found.</p>
                  <p className="mt-2 text-sm text-zinc-400">Try another title, author, or category.</p>
                </div>
              )}
            </section>
          </main>
        )}

        <footer className="mt-14 border-t border-white/10 py-8 text-sm text-zinc-500">
          OpenAudio Library only surfaces public domain material. Favorites, progress, and recently played items stay on
          your device, and Project Gutenberg links open directly to public domain editions.
        </footer>
      </div>

      <div className="fixed inset-x-0 bottom-0 z-40 border-t border-white/10 bg-zinc-950/92 backdrop-blur-2xl">
        <div className="mx-auto flex w-full max-w-7xl flex-col gap-4 px-4 py-4 sm:px-6 lg:px-8">
          {player && currentChapter ? (
            <>
              <div className="flex flex-col gap-4 lg:flex-row lg:items-center lg:justify-between">
                <div className="flex min-w-0 items-center gap-4">
                  <Cover title={player.book.title} coverUrl={player.book.coverUrl} className="h-16 w-14 shrink-0" />
                  <div className="min-w-0">
                    <p className="truncate text-sm font-medium text-white">{player.book.title}</p>
                    <p className="truncate text-sm text-zinc-400">{currentChapter.title}</p>
                  </div>
                </div>

                <div className="flex flex-wrap items-center gap-2">
                  <button
                    type="button"
                    onClick={togglePlayback}
                    className="rounded-2xl bg-white px-4 py-2.5 text-sm font-medium text-zinc-950 transition hover:bg-zinc-200"
                  >
                    {isPlaying ? "Pause" : "Play"}
                  </button>

                  <div className="flex items-center gap-2 rounded-2xl border border-white/10 bg-white/5 px-3 py-2.5 text-sm text-zinc-300">
                    <label htmlFor="speed" className="text-zinc-500">
                      Speed
                    </label>
                    <select
                      id="speed"
                      value={playbackRate}
                      onChange={(event) => setPlaybackRate(Number(event.target.value))}
                      className="bg-transparent text-zinc-100 outline-none"
                    >
                      {[0.5, 0.75, 1, 1.25, 1.5, 1.75, 2].map((rate) => (
                        <option key={rate} value={rate} className="bg-zinc-900">
                          {rate}x
                        </option>
                      ))}
                    </select>
                  </div>

                  <div className="flex items-center gap-2 rounded-2xl border border-white/10 bg-white/5 px-3 py-2.5 text-sm text-zinc-300">
                    <label htmlFor="sleep-timer" className="text-zinc-500">
                      Sleep
                    </label>
                    <select
                      id="sleep-timer"
                      value={sleepMinutes}
                      onChange={(event) => handleSleepTimer(Number(event.target.value))}
                      className="bg-transparent text-zinc-100 outline-none"
                    >
                      <option value={0} className="bg-zinc-900">
                        Off
                      </option>
                      <option value={15} className="bg-zinc-900">
                        15m
                      </option>
                      <option value={30} className="bg-zinc-900">
                        30m
                      </option>
                      <option value={45} className="bg-zinc-900">
                        45m
                      </option>
                      <option value={60} className="bg-zinc-900">
                        60m
                      </option>
                    </select>
                  </div>

                  <a
                    href={currentChapter.audioUrl}
                    target="_blank"
                    rel="noreferrer"
                    className="rounded-2xl border border-white/10 px-4 py-2.5 text-sm text-zinc-200 transition hover:border-white/20 hover:bg-white/5"
                  >
                    Download chapter
                  </a>
                </div>
              </div>

              <div className="grid gap-3 lg:grid-cols-[auto_minmax(0,1fr)_auto] lg:items-center">
                <span className="text-xs tabular-nums text-zinc-500">{formatClock(currentTime)}</span>
                <input
                  type="range"
                  min={0}
                  max={duration || currentChapter.durationSeconds || 0}
                  step={1}
                  value={Math.min(currentTime, duration || currentChapter.durationSeconds || 0)}
                  onChange={(event) => handleSeek(Number(event.target.value))}
                  className="h-2 w-full cursor-pointer appearance-none rounded-full bg-white/10"
                  aria-label="Seek audio position"
                />
                <span className="text-right text-xs tabular-nums text-zinc-500">
                  {formatClock(duration || currentChapter.durationSeconds || 0)}
                </span>
              </div>

              <div className="flex items-center justify-between text-xs text-zinc-500">
                <span>
                  {player.chapterIndex + 1} / {player.book.chapters.length} chapters
                </span>
                <span>{Math.round(currentProgress || 0)}% listened</span>
              </div>
            </>
          ) : (
            <div className="flex flex-col gap-2 text-sm text-zinc-500 sm:flex-row sm:items-center sm:justify-between">
              <span>Pick any public domain audiobook to start listening.</span>
              <span>Progress is saved locally on this device.</span>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
