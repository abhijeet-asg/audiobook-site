import type { CategoryId } from "./audiobooks";

const GUTENDEX_API = "https://gutendex.com/books";
const CACHE_PREFIX = "openaudio-gutenberg-cache";
const CACHE_AGE = 1000 * 60 * 60 * 12;

const CATEGORY_TOPICS: Record<CategoryId, string> = {
  Classics: "classics",
  Fiction: "fiction",
  Philosophy: "philosophy",
  "Self-Development": "self-help",
};

interface GutendexPerson {
  name?: string;
  birth_year?: number | null;
  death_year?: number | null;
}

interface GutendexBook {
  id: number;
  title?: string;
  authors?: GutendexPerson[];
  summaries?: string[];
  subjects?: string[];
  bookshelves?: string[];
  languages?: string[];
  copyright?: boolean | null;
  media_type?: string;
  formats?: Record<string, string>;
  download_count?: number;
}

interface GutendexResponse {
  count: number;
  next: string | null;
  previous: string | null;
  results: GutendexBook[];
}

export interface GutenbergBook {
  id: string;
  gutenbergId: number;
  title: string;
  author: string;
  summary: string;
  coverUrl?: string;
  mediaType: string;
  languages: string[];
  bookshelves: string[];
  subjects: string[];
  downloadCount: number;
  sourceUrl: string;
  readUrl?: string;
  htmlUrl?: string;
  textUrl?: string;
  epubUrl?: string;
  kindleUrl?: string;
  zipUrl?: string;
  audioUrl?: string;
}

export interface GutenbergCollection {
  total: number;
  nextUrl: string | null;
  previousUrl: string | null;
  books: GutenbergBook[];
}

function getStorage() {
  if (typeof window === "undefined") return null;
  return window.localStorage;
}

function getCached<T>(key: string, maxAge: number): T | null {
  const storage = getStorage();
  if (!storage) return null;

  try {
    const raw = storage.getItem(`${CACHE_PREFIX}:${key}`);
    if (!raw) return null;

    const parsed = JSON.parse(raw) as { timestamp: number; data: T };
    if (Date.now() - parsed.timestamp > maxAge) {
      storage.removeItem(`${CACHE_PREFIX}:${key}`);
      return null;
    }

    return parsed.data;
  } catch {
    return null;
  }
}

function setCached<T>(key: string, data: T) {
  const storage = getStorage();
  if (!storage) return;

  try {
    storage.setItem(
      `${CACHE_PREFIX}:${key}`,
      JSON.stringify({
        timestamp: Date.now(),
        data,
      }),
    );
  } catch {
    // Ignore storage quota issues.
  }
}

function normalizeUrl(url?: string | null) {
  if (!url) return undefined;
  return url.replace(/^http:/i, "https:");
}

function cleanText(value: unknown) {
  const input = Array.isArray(value) ? value.join(" ") : String(value ?? "");
  return input.replace(/<[^>]+>/g, " ").replace(/\s+/g, " ").trim();
}

function formatAuthorName(person: GutendexPerson) {
  const name = cleanText(person.name);
  if (!name) return "";

  if (!name.includes(",")) return name;

  const [lastName, ...rest] = name.split(",").map((part) => part.trim()).filter(Boolean);
  return [...rest, lastName].join(" ").trim();
}

function toAuthorLabel(authors?: GutendexPerson[]) {
  if (!authors?.length) return "Unknown author";

  const names = authors.map(formatAuthorName).filter(Boolean);
  return names.length ? names.join(", ") : "Unknown author";
}

function pickFormatUrl(formats: Record<string, string>, prefixes: string[]) {
  for (const prefix of prefixes) {
    const entry = Object.entries(formats).find(([mime]) => mime.toLowerCase().startsWith(prefix.toLowerCase()));
    if (entry?.[1]) {
      return normalizeUrl(entry[1]);
    }
  }

  return undefined;
}

function dedupeBooks(books: GutenbergBook[]) {
  const seen = new Set<string>();
  return books.filter((book) => {
    if (seen.has(book.id)) return false;
    seen.add(book.id);
    return true;
  });
}

function mapBook(book: GutendexBook): GutenbergBook {
  const formats = book.formats ?? {};
  const htmlUrl = pickFormatUrl(formats, ["text/html"]);
  const textUrl = pickFormatUrl(formats, ["text/plain"]);
  const epubUrl = pickFormatUrl(formats, ["application/epub+zip"]);
  const kindleUrl = pickFormatUrl(formats, ["application/x-mobipocket-ebook"]);
  const zipUrl = pickFormatUrl(formats, ["application/octet-stream"]);
  const audioUrl = pickFormatUrl(formats, ["audio/mpeg", "audio/mp4", "audio/ogg"]);
  const imageUrl = normalizeUrl(formats["image/jpeg"]);

  return {
    id: `gutenberg:${book.id}`,
    gutenbergId: book.id,
    title: cleanText(book.title) || `Project Gutenberg #${book.id}`,
    author: toAuthorLabel(book.authors),
    summary: cleanText(book.summaries) || "Public domain book from Project Gutenberg.",
    coverUrl: imageUrl || `https://www.gutenberg.org/cache/epub/${book.id}/pg${book.id}.cover.medium.jpg`,
    mediaType: cleanText(book.media_type) || "Text",
    languages: (book.languages ?? []).map((language) => cleanText(language)).filter(Boolean),
    bookshelves: (book.bookshelves ?? []).map((shelf) => cleanText(shelf)).filter(Boolean),
    subjects: (book.subjects ?? []).map((subject) => cleanText(subject)).filter(Boolean),
    downloadCount: Number(book.download_count ?? 0),
    sourceUrl: `https://www.gutenberg.org/ebooks/${book.id}`,
    readUrl: htmlUrl || textUrl,
    htmlUrl,
    textUrl,
    epubUrl,
    kindleUrl,
    zipUrl,
    audioUrl,
  };
}

async function fetchCollection(url: string) {
  const response = await fetch(url);
  if (!response.ok) {
    throw new Error("Unable to load Project Gutenberg books.");
  }

  const data = (await response.json()) as GutendexResponse;
  return {
    total: Number(data.count ?? 0),
    nextUrl: normalizeUrl(data.next) ?? null,
    previousUrl: normalizeUrl(data.previous) ?? null,
    books: dedupeBooks(
      (data.results ?? [])
        .filter((book) => book.copyright === false || book.copyright === null || typeof book.copyright === "undefined")
        .map(mapBook),
    ),
  } satisfies GutenbergCollection;
}

function buildUrl(params: URLSearchParams) {
  return `${GUTENDEX_API}?${params.toString()}`;
}

async function fetchWithCache(url: string) {
  const cacheKey = encodeURIComponent(url);
  const cached = getCached<GutenbergCollection>(cacheKey, CACHE_AGE);
  if (cached) return cached;

  const data = await fetchCollection(url);
  setCached(cacheKey, data);
  return data;
}

export async function searchGutenbergBooks(query: string, pageUrl?: string) {
  const trimmed = query.trim();
  if (!trimmed && !pageUrl) {
    return {
      total: 0,
      nextUrl: null,
      previousUrl: null,
      books: [],
    } satisfies GutenbergCollection;
  }

  if (pageUrl) {
    return fetchWithCache(pageUrl);
  }

  const params = new URLSearchParams({
    search: trimmed,
    copyright: "false",
  });

  return fetchWithCache(buildUrl(params));
}

export async function getGutenbergCollection(category: CategoryId, pageUrl?: string) {
  if (pageUrl) {
    return fetchWithCache(pageUrl);
  }

  const params = new URLSearchParams({
    copyright: "false",
    topic: CATEGORY_TOPICS[category],
  });

  return fetchWithCache(buildUrl(params));
}

export async function getPopularGutenbergBooks(pageUrl?: string) {
  if (pageUrl) {
    return fetchWithCache(pageUrl);
  }

  const params = new URLSearchParams({
    copyright: "false",
    sort: "popular",
  });

  return fetchWithCache(buildUrl(params));
}
