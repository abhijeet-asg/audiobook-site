export const CATEGORY_OPTIONS = [
  {
    id: "Classics",
    label: "Classics",
    description: "Timeless novels and enduring literary staples.",
  },
  {
    id: "Fiction",
    label: "Fiction",
    description: "Stories, adventures, mysteries, and imaginative worlds.",
  },
  {
    id: "Philosophy",
    label: "Philosophy",
    description: "Works on ethics, reflection, and the examined life.",
  },
  {
    id: "Self-Development",
    label: "Self-Development",
    description: "Practical public domain books on character and self-mastery.",
  },
] as const;

export type CategoryId = (typeof CATEGORY_OPTIONS)[number]["id"];
export type SourceKind = "librivox" | "archive";

export interface Chapter {
  id: string;
  title: string;
  audioUrl: string;
  durationSeconds: number;
  durationLabel: string;
  reader?: string;
}

export interface AudiobookPreview {
  id: string;
  source: SourceKind;
  sourceId: string;
  archiveId?: string;
  title: string;
  author: string;
  description: string;
  coverUrl?: string;
  durationSeconds: number;
  durationLabel: string;
  chapterCount: number;
  categories: string[];
  sourceUrl?: string;
  downloadUrl?: string;
}

export interface Audiobook extends AudiobookPreview {
  chapters: Chapter[];
}

interface LibriVoxAuthor {
  first_name?: string;
  last_name?: string;
}

interface LibriVoxReader {
  display_name?: string;
}

interface LibriVoxSection {
  id?: string | number;
  section_number?: string | number;
  title?: string;
  listen_url?: string;
  playtime?: string | number;
  readers?: LibriVoxReader[];
}

interface LibriVoxGenre {
  name?: string;
}

interface LibriVoxBook {
  id?: string | number;
  title?: string;
  description?: string;
  authors?: LibriVoxAuthor[];
  sections?: LibriVoxSection[];
  num_sections?: string | number;
  coverart_thumbnail?: string;
  coverart_jpg?: string;
  url_iarchive?: string;
  url_librivox?: string;
  url_zip_file?: string;
  totaltime?: string | number;
  totaltimesecs?: string | number;
  genres?: LibriVoxGenre[];
}

const LIBRIVOX_API = "https://librivox.org/api/feed/audiobooks";
const ARCHIVE_SEARCH_API = "https://cors.archive.org/advancedsearch.php";
const ARCHIVE_METADATA_API = "https://cors.archive.org/metadata";
const CACHE_PREFIX = "openaudio-cache";
const SEARCH_CACHE_AGE = 1000 * 60 * 60 * 6;
const DETAIL_CACHE_AGE = 1000 * 60 * 60 * 24;

const CATEGORY_SEEDS: Record<CategoryId, string[]> = {
  Classics: [
    "Pride and Prejudice",
    "Jane Eyre",
    "Moby Dick",
    "The Railway Children",
    "Little Women",
    "Wuthering Heights",
    "Great Expectations",
    "Anna Karenina",
    "The Secret Garden",
    "Treasure Island",
    "The Count of Monte Cristo",
    "Frankenstein",
    "Dracula",
    "The Adventures of Tom Sawyer",
    "The Picture of Dorian Gray",
    "David Copperfield",
    "Les Miserables",
    "The Brothers Karamazov",
    "Crime and Punishment",
    "Persuasion",
  ],
  Fiction: [
    "Sherlock Holmes",
    "The Adventures of Sherlock Holmes",
    "The Hound of the Baskervilles",
    "Treasure Island",
    "Dracula",
    "Frankenstein",
    "The Secret Garden",
    "Alice in Wonderland",
    "The Hobbit",
    "Twenty Thousand Leagues",
    "Journey to the Center",
    "The Time Machine",
    "The War of the Worlds",
    "Dr Jekyll and Mr Hyde",
    "The Invisible Man",
    "The Island of Dr Moreau",
    "Around the World in 80 Days",
    "Robinson Crusoe",
    "Gulliver's Travels",
    "The Three Musketeers",
  ],
  Philosophy: [
    "Meditations",
    "The Republic",
    "Walden",
    "Confessions",
    "Thus Spoke Zarathustra",
    "Beyond Good and Evil",
    "The Art of War",
    "Tao Te Ching",
    "The Prince",
    "On Liberty",
    "Utilitarianism",
    "Critique of Pure Reason",
    "The Nicomachean Ethics",
    "Discourse on Method",
    "Leviathan",
    "The Social Contract",
    "Essays of Montaigne",
    "The Enchiridion",
    "Letters from a Stoic",
    "The Consolation of Philosophy",
  ],
  "Self-Development": [
    "As a Man Thinketh",
    "Self-Reliance",
    "Character",
    "The Art of War",
    "Walden",
    "The Science of Getting Rich",
    "Think and Grow Rich",
    "The Power of Concentration",
    "How to Live on 24 Hours",
    "The Art of Money Getting",
    "Acres of Diamonds",
    "The Game of Life",
    "The Master Key System",
    "The Strangest Secret",
    "A Message to Garcia",
    "The Way to Wealth",
    "How to Win Friends",
    "Self Help Smiles",
    "The Inner Consciousness",
    "Thought Vibration",
  ],
};

const FEATURED_SEEDS = [
  "Pride and Prejudice",
  "Sherlock Holmes",
  "Meditations",
  "As a Man Thinketh",
  "Moby Dick",
  "Dracula",
  "Frankenstein",
  "Little Women",
  "The Republic",
  "Walden",
  "Treasure Island",
  "Great Expectations",
];

function getStorage() {
  if (typeof window === "undefined") return null;
  return window.localStorage;
}

function getCached<T>(key: string, maxAge: number): T | null {
  const storage = getStorage();
  if (!storage) return null;

  try {
    const raw = storage.getItem(`${CACHE_PREFIX}:${key}`);
    if (!raw) return null;

    const parsed = JSON.parse(raw) as { timestamp: number; data: T };
    if (Date.now() - parsed.timestamp > maxAge) {
      storage.removeItem(`${CACHE_PREFIX}:${key}`);
      return null;
    }

    return parsed.data;
  } catch {
    return null;
  }
}

function setCached<T>(key: string, data: T) {
  const storage = getStorage();
  if (!storage) return;

  try {
    storage.setItem(
      `${CACHE_PREFIX}:${key}`,
      JSON.stringify({
        timestamp: Date.now(),
        data,
      }),
    );
  } catch {
    // Ignore storage quota issues.
  }
}

function normalizeKey(input: string) {
  return input.trim().toLowerCase().replace(/\s+/g, "-");
}

function textFromUnknown(value: unknown): string {
  if (Array.isArray(value)) {
    return value
      .map((entry) => textFromUnknown(entry))
      .filter(Boolean)
      .join(" ");
  }

  if (value === null || value === undefined) return "";
  return String(value);
}

function cleanText(value: unknown) {
  const input = textFromUnknown(value);
  if (!input) return "";

  if (typeof DOMParser !== "undefined") {
    const parsed = new DOMParser().parseFromString(input, "text/html");
    return parsed.body.textContent?.replace(/\s+/g, " ").trim() ?? "";
  }

  return input.replace(/<[^>]+>/g, " ").replace(/\s+/g, " ").trim();
}

function toAuthorName(authors?: LibriVoxAuthor[]) {
  if (!authors?.length) return "Unknown author";
  return authors
    .map((author) => [author.first_name, author.last_name].filter(Boolean).join(" ").trim())
    .filter(Boolean)
    .join(", ");
}

function toStringArray(value: unknown) {
  if (Array.isArray(value)) {
    return value.map((entry) => cleanText(entry)).filter(Boolean);
  }

  const single = cleanText(value);
  return single ? [single] : [];
}

function splitSubjects(value: unknown) {
  return toStringArray(value)
    .flatMap((entry) => entry.split(/[;,|]/g))
    .map((entry) => entry.trim())
    .filter(Boolean)
    .slice(0, 6);
}

function parseDurationToSeconds(value: unknown): number {
  if (typeof value === "number") {
    return Number.isFinite(value) ? value : 0;
  }

  const text = String(value ?? "").trim();
  if (!text) return 0;

  if (/^\d+(\.\d+)?$/.test(text)) {
    return Math.round(Number(text));
  }

  const parts = text.split(":").map((part) => Number(part));
  if (parts.some((part) => Number.isNaN(part))) return 0;

  if (parts.length === 3) {
    return parts[0] * 3600 + parts[1] * 60 + parts[2];
  }

  if (parts.length === 2) {
    return parts[0] * 60 + parts[1];
  }

  return 0;
}

export function formatClock(seconds: number) {
  const safe = Math.max(0, Math.floor(seconds || 0));
  const hours = Math.floor(safe / 3600);
  const minutes = Math.floor((safe % 3600) / 60);
  const secs = safe % 60;

  if (hours > 0) {
    return `${hours}:${String(minutes).padStart(2, "0")}:${String(secs).padStart(2, "0")}`;
  }

  return `${minutes}:${String(secs).padStart(2, "0")}`;
}

function formatDurationLabel(seconds: number) {
  if (!seconds) return "—";

  const hours = Math.floor(seconds / 3600);
  const minutes = Math.floor((seconds % 3600) / 60);

  if (hours > 0) {
    return `${hours}h ${minutes}m`;
  }

  if (minutes > 0) {
    return `${minutes}m`;
  }

  return `${Math.max(1, Math.floor(seconds))}s`;
}

function getArchiveId(url?: string) {
  if (!url) return undefined;
  const match = url.match(/\/details\/([^/?#]+)/i);
  return match?.[1];
}

function dedupeBooks(books: AudiobookPreview[]) {
  const seen = new Set<string>();
  return books.filter((book) => {
    if (seen.has(book.id)) return false;
    seen.add(book.id);
    return true;
  });
}

function sortByTrack(
  a: { track?: unknown; section_number?: unknown; name?: unknown; title?: unknown },
  b: { track?: unknown; section_number?: unknown; name?: unknown; title?: unknown },
) {
  const trackA = parseInt(String(a.track ?? a.section_number ?? "").split("/")[0], 10);
  const trackB = parseInt(String(b.track ?? b.section_number ?? "").split("/")[0], 10);

  if (!Number.isNaN(trackA) && !Number.isNaN(trackB) && trackA !== trackB) {
    return trackA - trackB;
  }

  const fallbackA = String(a.name ?? a.title ?? "");
  const fallbackB = String(b.name ?? b.title ?? "");
  return fallbackA.localeCompare(fallbackB, undefined, { numeric: true, sensitivity: "base" });
}

async function fetchJsonp<T>(url: string): Promise<T> {
  if (typeof document === "undefined" || typeof window === "undefined") {
    throw new Error("JSONP is only available in the browser.");
  }

  return new Promise<T>((resolve, reject) => {
    const callbackName = `__openaudio_jsonp_${Date.now()}_${Math.random().toString(36).slice(2)}`;
    const script = document.createElement("script");
    const timer = window.setTimeout(() => {
      cleanup();
      reject(new Error("Request timed out."));
    }, 12000);

    const globalWindow = window as Window & typeof globalThis & Record<string, (data: T) => void>;

    function cleanup() {
      window.clearTimeout(timer);
      delete globalWindow[callbackName];
      script.remove();
    }

    globalWindow[callbackName] = (data: T) => {
      cleanup();
      resolve(data);
    };

    script.onerror = () => {
      cleanup();
      reject(new Error("JSONP request failed."));
    };

    script.src = `${url}${url.includes("?") ? "&" : "?"}callback=${callbackName}`;
    document.body.appendChild(script);
  });
}

async function fetchLibriVox<T>(params: URLSearchParams) {
  const url = `${LIBRIVOX_API}?${params.toString()}&format=json`;

  try {
    const response = await fetch(url);
    if (response.ok) {
      return (await response.json()) as T;
    }
  } catch {
    // Fall back to JSONP below.
  }

  return fetchJsonp<T>(`${LIBRIVOX_API}?${params.toString()}&format=jsonp`);
}

function mapLibriVoxBook(book: LibriVoxBook): Audiobook {
  const archiveId = getArchiveId(book.url_iarchive);
  const chapters = (book.sections ?? [])
    .slice()
    .sort(sortByTrack)
    .map((section) => {
      const durationSeconds = parseDurationToSeconds(section.playtime);
      const reader = (section.readers ?? [])
        .map((entry) => cleanText(entry.display_name))
        .filter(Boolean)
        .join(", ");

      const rawUrl = String(section.listen_url ?? "");
      const proxiedUrl = archiveId && rawUrl.includes("archive.org")
        ? rawUrl.replace("https://archive.org/", "https://cors.archive.org/").replace("http://archive.org/", "https://cors.archive.org/")
        : rawUrl;

      return {
        id: `chapter-${section.id ?? section.section_number ?? Math.random().toString(36).slice(2)}`,
        title: cleanText(section.title) || `Chapter ${section.section_number ?? ""}`.trim(),
        audioUrl: proxiedUrl,
        durationSeconds,
        durationLabel: formatDurationLabel(durationSeconds),
        reader: reader || undefined,
      } satisfies Chapter;
    })
    .filter((chapter) => chapter.audioUrl);

  const durationSeconds = parseDurationToSeconds(book.totaltimesecs ?? book.totaltime);

  const coverArt = book.coverart_thumbnail || book.coverart_jpg;

  return {
    id: `librivox:${book.id}`,
    source: "librivox",
    sourceId: String(book.id ?? ""),
    archiveId,
    title: cleanText(book.title) || "Untitled audiobook",
    author: toAuthorName(book.authors),
    description: cleanText(book.description) || "Public domain audiobook from LibriVox.",
    coverUrl: archiveId ? `https://archive.org/services/img/${archiveId}` : coverArt,
    durationSeconds,
    durationLabel: formatDurationLabel(durationSeconds),
    chapterCount: Number(book.num_sections ?? chapters.length ?? 0),
    categories: (book.genres ?? []).map((genre) => cleanText(genre.name)).filter(Boolean),
    sourceUrl: book.url_librivox || book.url_iarchive,
    downloadUrl: book.url_zip_file
      ? book.url_zip_file.replace("https://archive.org/", "https://cors.archive.org/")
      : book.url_librivox || book.url_iarchive,
    chapters,
  };
}

async function searchLibriVoxByField(field: "title" | "author", query: string, limit = 8) {
  const params = new URLSearchParams({
    [field]: query,
    limit: String(limit),
    offset: "0",
    coverart: "1",
  });

  [
    "id",
    "title",
    "description",
    "authors",
    "url_iarchive",
    "url_librivox",
    "url_zip_file",
    "totaltime",
    "totaltimesecs",
    "num_sections",
    "genres",
    "coverart_thumbnail",
    "coverart_jpg",
  ].forEach((fieldName) => params.append("fields[]", fieldName));

  const response = await fetchLibriVox<{ books?: LibriVoxBook[] }>(params);
  return (response.books ?? []).map((book) => {
    const mapped = mapLibriVoxBook(book);
    return {
      ...mapped,
      chapters: undefined,
    } as unknown as AudiobookPreview;
  });
}

async function fetchArchiveMetadata(identifier: string) {
  const response = await fetch(`${ARCHIVE_METADATA_API}/${encodeURIComponent(identifier)}`);
  if (!response.ok) {
    throw new Error("Unable to load archive metadata.");
  }
  return response.json() as Promise<Record<string, unknown>>;
}

function mapArchiveMetadata(
  identifier: string,
  payload: Record<string, unknown>,
  preview?: Partial<AudiobookPreview>,
): Audiobook {
  const metadata = (payload.metadata as Record<string, unknown> | undefined) ?? {};
  const files = Array.isArray(payload.files) ? (payload.files as Record<string, unknown>[]) : [];

  const lowBitrateTracks = files.filter(
    (file) => /mp3/i.test(String(file.name ?? "")) && /64\s*k?bps\s*mp3/i.test(String(file.format ?? "")),
  );

  const standardTracks = files.filter(
    (file) =>
      /mp3/i.test(String(file.name ?? "")) &&
      /mp3/i.test(String(file.format ?? "")) &&
      !/zip|m3u/i.test(String(file.format ?? "")),
  );

  const sourceTracks = (lowBitrateTracks.length ? lowBitrateTracks : standardTracks).slice().sort(sortByTrack);

  const chapters: Chapter[] = sourceTracks.map((file, index) => {
    const durationSeconds = parseDurationToSeconds(file.length);
    return {
      id: `chapter-${identifier}-${index + 1}`,
      title: cleanText(file.title) || `Chapter ${index + 1}`,
      audioUrl: `https://cors.archive.org/download/${identifier}/${encodeURIComponent(String(file.name ?? ""))}`,
      durationSeconds,
      durationLabel: formatDurationLabel(durationSeconds),
      reader: cleanText(file.comment) || undefined,
    };
  });

  if (!chapters.length) {
    const audiobookFile = files.find(
      (file) => /\.(m4b|mp3)$/i.test(String(file.name ?? "")) && /audiobook|mp3/i.test(String(file.format ?? "")),
    );

    if (audiobookFile) {
      const durationSeconds = parseDurationToSeconds(audiobookFile.length);
      chapters.push({
        id: `chapter-${identifier}-full`,
        title: "Full audiobook",
        audioUrl: `https://cors.archive.org/download/${identifier}/${encodeURIComponent(String(audiobookFile.name ?? ""))}`,
        durationSeconds,
        durationLabel: formatDurationLabel(durationSeconds),
      });
    }
  }

  const durationSeconds =
    chapters.reduce((total, chapter) => total + chapter.durationSeconds, 0) ||
    parseDurationToSeconds(files.find((file) => /zip/i.test(String(file.format ?? "")))?.length) ||
    preview?.durationSeconds ||
    0;

  const creator = toStringArray(metadata.creator).join(", ") || preview?.author || "Unknown author";
  const description =
    cleanText(metadata.description) || preview?.description || "Public domain audiobook from the Internet Archive.";
  const categories = splitSubjects(metadata.subject);

  const downloadCandidate = files.find(
    (file) => /\.(m4b|zip|mp3)$/i.test(String(file.name ?? "")) && !/m3u/i.test(String(file.name ?? "")),
  );

  return {
    id: `archive:${identifier}`,
    source: "archive",
    sourceId: identifier,
    archiveId: identifier,
    title: cleanText(metadata.title) || preview?.title || identifier.replace(/[_-]+/g, " "),
    author: creator,
    description,
    coverUrl: `https://archive.org/services/img/${identifier}`,
    durationSeconds,
    durationLabel: formatDurationLabel(durationSeconds),
    chapterCount: chapters.length || preview?.chapterCount || 0,
    categories: categories.length ? categories : preview?.categories ?? [],
    sourceUrl: `https://archive.org/details/${identifier}`,
    downloadUrl: downloadCandidate
      ? `https://cors.archive.org/download/${identifier}/${encodeURIComponent(String(downloadCandidate.name ?? ""))}`
      : preview?.downloadUrl?.replace("https://archive.org/", "https://cors.archive.org/"),
    chapters,
  };
}

async function searchInternetArchive(query: string, limit = 6): Promise<AudiobookPreview[]> {
  const params = new URLSearchParams({
    q: `${query} AND collection:librivoxaudio AND mediatype:audio`,
    rows: String(limit),
    output: "json",
  });

  ["identifier", "title", "creator", "description"].forEach((field) => params.append("fl[]", field));

  const response = await fetch(`${ARCHIVE_SEARCH_API}?${params.toString()}`);
  if (!response.ok) {
    throw new Error("Unable to search the Internet Archive.");
  }

  const data = (await response.json()) as {
    response?: {
      docs?: Array<Record<string, unknown>>;
    };
  };

  const docs = data.response?.docs ?? [];

  const results = await Promise.all(
    docs.slice(0, limit).map(async (doc) => {
      const identifier = cleanText(doc.identifier);
      const preview: Partial<AudiobookPreview> = {
        title: cleanText(doc.title) || "Untitled audiobook",
        author: cleanText(doc.creator) || "Unknown author",
        description: cleanText(doc.description) || "Public domain audiobook from the Internet Archive.",
        coverUrl: identifier ? `https://archive.org/services/img/${identifier}` : undefined,
        durationSeconds: 0,
        chapterCount: 0,
        categories: [],
      };

      if (!identifier) {
        return {
          id: `archive:unknown-${Math.random().toString(36).slice(2)}`,
          source: "archive",
          sourceId: "",
          title: preview.title || "Untitled audiobook",
          author: preview.author || "Unknown author",
          description: preview.description || "",
          coverUrl: preview.coverUrl,
          durationSeconds: 0,
          durationLabel: "—",
          chapterCount: 0,
          categories: [],
        } satisfies AudiobookPreview;
      }

      try {
        const metadata = await fetchArchiveMetadata(identifier);
        const mapped = mapArchiveMetadata(identifier, metadata, preview);
        return {
          ...mapped,
          chapters: undefined,
        } as unknown as AudiobookPreview;
      } catch {
        return {
          id: `archive:${identifier}`,
          source: "archive",
          sourceId: identifier,
          archiveId: identifier,
          title: preview.title || "Untitled audiobook",
          author: preview.author || "Unknown author",
          description: preview.description || "",
          coverUrl: preview.coverUrl,
          durationSeconds: 0,
          durationLabel: "—",
          chapterCount: 0,
          categories: [],
          sourceUrl: `https://archive.org/details/${identifier}`,
        } satisfies AudiobookPreview;
      }
    }),
  );

  return results;
}

export async function searchAudiobooks(query: string) {
  const normalized = query.trim();
  if (!normalized) return [];

  const cacheKey = `search:${normalizeKey(normalized)}`;
  const cached = getCached<AudiobookPreview[]>(cacheKey, SEARCH_CACHE_AGE);
  if (cached) return cached;

  const [titleResults, authorResults] = await Promise.allSettled([
    searchLibriVoxByField("title", normalized, 8),
    searchLibriVoxByField("author", normalized, 8),
  ]);

  const merged = dedupeBooks([
    ...(titleResults.status === "fulfilled" ? titleResults.value : []),
    ...(authorResults.status === "fulfilled" ? authorResults.value : []),
  ]);

  let finalResults = merged;

  if (finalResults.length < 8) {
    try {
      const fallback = await searchInternetArchive(normalized, 8 - finalResults.length);
      finalResults = dedupeBooks([...finalResults, ...fallback]);
    } catch {
      // Ignore fallback errors if primary results already exist.
    }
  }

  const sliced = finalResults.slice(0, 12);
  setCached(cacheKey, sliced);
  return sliced;
}

export async function getFeaturedAudiobooks() {
  const cacheKey = "featured";
  const cached = getCached<AudiobookPreview[]>(cacheKey, SEARCH_CACHE_AGE);
  if (cached) return cached;

  const featured = await Promise.all(
    FEATURED_SEEDS.map(async (seed) => {
      const results = await searchLibriVoxByField("title", seed, 4);
      return results[0];
    }),
  );

  const filtered = dedupeBooks(featured.filter(Boolean) as AudiobookPreview[]);
  setCached(cacheKey, filtered);
  return filtered;
}

export async function getCategoryCollection(category: CategoryId) {
  const cacheKey = `category:${normalizeKey(category)}`;
  const cached = getCached<AudiobookPreview[]>(cacheKey, SEARCH_CACHE_AGE);
  if (cached) return cached;

  const seeds = CATEGORY_SEEDS[category];
  const results = await Promise.allSettled(seeds.map((seed) => searchLibriVoxByField("title", seed, 4)));
  let merged = dedupeBooks(
    results.flatMap((result) => (result.status === "fulfilled" ? result.value : [])),
  ).slice(0, 12);

  if (!merged.length) {
    try {
      merged = await searchInternetArchive(category, 8);
    } catch {
      merged = [];
    }
  }

  setCached(cacheKey, merged);
  return merged;
}

export async function getAudiobookDetails(preview: AudiobookPreview) {
  const cacheKey = `details:${preview.id}`;
  const cached = getCached<Audiobook>(cacheKey, DETAIL_CACHE_AGE);
  if (cached) return cached;

  let result: Audiobook;

  if (preview.source === "librivox") {
    const params = new URLSearchParams({
      id: preview.sourceId,
      extended: "1",
      coverart: "1",
    });
    const response = await fetchLibriVox<{ books?: LibriVoxBook[] }>(params);
    const book = response.books?.[0];

    if (!book) {
      throw new Error("Audiobook details could not be loaded.");
    }

    const mapped = mapLibriVoxBook(book);
    result = {
      ...mapped,
      categories: mapped.categories.length ? mapped.categories : preview.categories,
    };
  } else {
    const metadata = await fetchArchiveMetadata(preview.sourceId);
    result = mapArchiveMetadata(preview.sourceId, metadata, preview);
  }

  setCached(cacheKey, result);
  return result;
}
